﻿# PPC Lead Generation Platform

Config-driven Pay-Per-Call lead-generation platform. Version 1 launches emergency plumbing and drain cleaning pages for Dallas-Fort Worth.

PPC means Pay-Per-Call in this repo, not pay-per-click advertising.

## What Is Built
- Next.js App Router application
- TypeScript data-driven services, cities, city plus service pages, problem pages, cost guides, blog posts, FAQ, contact, partner, privacy, terms, and disclosure pages
- SEO metadata, canonical URLs, sitemap, robots, and schema helpers
- AEO direct answer blocks, FAQs, emergency steps, cost guidance, local guidance, and internal links
- lead form API at `/api/lead`
- call event API at `/api/call-event`
- buyer routing model in `src/data/buyers.ts` and `src/lib/routing.ts`
- QA and report generation scripts
- reusable blueprint archive and D-drive backup script

## Local Commands
On a normal laptop with Node installed, run:

```powershell
pnpm install
pnpm run reports
pnpm run qa
pnpm run build
pnpm run dev
```

If `npm` or `pnpm` is not on PATH, install Node.js locally or use the Codex bundled runtime.

## Environment
Copy `.env.example` to `.env.local` for local values. Do not commit real keys or private credentials.

The owner must replace sample tracking phone values before public launch.

## Important URLs
- Sitemap: `/sitemap.xml`
- Robots: `/robots.txt`
- Lead API: `/api/lead`
- Call event API: `/api/call-event`

## Safety
Do not create paid ads, Google Ads, Bing Ads, fake Google Business Profiles, fake addresses, fake reviews, fake licenses, fake insurance claims, fake local office claims, copied competitor images, or spam backlinks.
