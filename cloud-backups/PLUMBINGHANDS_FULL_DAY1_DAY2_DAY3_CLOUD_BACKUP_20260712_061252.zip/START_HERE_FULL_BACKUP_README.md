﻿# START HERE — PlumbingHands Full Day 1-Day 3 Cloud Backup

Created:
20260712_061252

Live project:
https://plumbinghands.com

Purpose:
This backup stores the full working system so future projects like window installation, water damage, HVAC, roofing, electrical, garage door, and pest control can start faster instead of from zero.

This backup includes:
- Day 1 foundation workflow
- Day 2 SEO/AEO content workflow
- Day 3 premium design cleanup workflow
- full command-center files
- full scripts folder
- full reports folder
- full blueprints folder
- reusable source/template folders
- what to do and what not to do
- Google Search Console process
- IndexNow process
- safe design/image rules
- future project reuse checklist

This backup excludes:
- passwords
- API keys
- Hostinger tokens
- Google/Bing tokens
- OTPs
- .env secrets
- node_modules
- .next
- .vercel
- .git folder

Open first:
blueprints/PPC_LOCAL_LEADGEN_0_TO_FINAL_REUSABLE_CLOUD_BLUEPRINT.md

Then open:
blueprints/NEXT_PROJECT_FAST_START_CHECKLIST.md
blueprints/REUSABLE_COMMAND_LIBRARY.md
command-center/
scripts/
reports/
