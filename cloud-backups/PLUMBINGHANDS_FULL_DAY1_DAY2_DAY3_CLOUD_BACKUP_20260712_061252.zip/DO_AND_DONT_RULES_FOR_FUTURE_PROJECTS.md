﻿# What To Do / What Not To Do For Future Projects

## Do

- Choose one niche first.
- Choose one city/market first.
- Build homepage, services, city pages, problem pages, cost guides, FAQs.
- Use honest disclosure if connecting users with providers.
- Use Google Search Console.
- Submit sitemap.
- Use IndexNow after sitemap is stable.
- Add safe original visuals/icons.
- Keep internal strategy inside blueprints only.

## Do Not

- Do not show Pay Per Call/PPC publicly.
- Do not expose buyer routing publicly.
- Do not expose internal prompts publicly.
- Do not claim fake offices.
- Do not create fake Google Business Profiles.
- Do not create fake reviews.
- Do not use fake ratings.
- Do not claim licensed/insured unless verified.
- Do not copy competitor images.
- Do not copy competitor text.
- Do not use spam backlinks.
- Do not paste API keys into ChatGPT, Codex, GitHub, or public files.
