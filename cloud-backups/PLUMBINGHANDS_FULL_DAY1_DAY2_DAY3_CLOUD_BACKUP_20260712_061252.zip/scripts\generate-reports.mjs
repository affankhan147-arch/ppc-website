import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const reportsDir = join(process.cwd(), "reports");
mkdirSync(reportsDir, { recursive: true });

const productionDomain = "https://plumbinghands.com";
const productionWwwDomain = "https://www.plumbinghands.com";

const services = [
  "24-hour-emergency-plumber",
  "emergency-drain-cleaning",
  "main-sewer-line-clog",
  "toilet-overflow-emergency",
  "burst-pipe-emergency",
  "water-heater-emergency",
  "sewer-backup-help",
  "commercial-emergency-plumbing",
  "same-day-plumber-connection",
  "sink-and-shower-drain-backup"
];

const serviceNames = [
  "24-hour emergency plumber",
  "emergency drain cleaning",
  "main sewer line clog",
  "toilet overflow emergency",
  "burst pipe emergency",
  "water heater emergency",
  "sewer backup help",
  "commercial emergency plumbing",
  "same-day plumber connection",
  "sink and shower drain backup"
];

const cities = [
  "dallas",
  "fort-worth",
  "arlington",
  "plano",
  "irving",
  "garland",
  "frisco",
  "mckinney",
  "denton",
  "lewisville",
  "carrollton",
  "richardson",
  "grand-prairie",
  "mesquite",
  "grapevine",
  "euless",
  "bedford",
  "hurst",
  "keller",
  "southlake",
  "flower-mound",
  "the-colony",
  "allen",
  "rockwall",
  "rowlett",
  "mansfield",
  "cedar-hill",
  "desoto",
  "duncanville",
  "wylie"
];

const cityNames = [
  "Dallas",
  "Fort Worth",
  "Arlington",
  "Plano",
  "Irving",
  "Garland",
  "Frisco",
  "McKinney",
  "Denton",
  "Lewisville",
  "Carrollton",
  "Richardson",
  "Grand Prairie",
  "Mesquite",
  "Grapevine",
  "Euless",
  "Bedford",
  "Hurst",
  "Keller",
  "Southlake",
  "Flower Mound",
  "The Colony",
  "Allen",
  "Rockwall",
  "Rowlett",
  "Mansfield",
  "Cedar Hill",
  "DeSoto",
  "Duncanville",
  "Wylie"
];

const cityServiceCombos = [
  ["dallas", "24-hour-emergency-plumber"],
  ["dallas", "emergency-drain-cleaning"],
  ["fort-worth", "24-hour-emergency-plumber"],
  ["fort-worth", "emergency-drain-cleaning"],
  ["arlington", "24-hour-emergency-plumber"],
  ["arlington", "emergency-drain-cleaning"],
  ["plano", "24-hour-emergency-plumber"],
  ["plano", "emergency-drain-cleaning"],
  ["irving", "24-hour-emergency-plumber"],
  ["irving", "emergency-drain-cleaning"],
  ["garland", "24-hour-emergency-plumber"],
  ["garland", "emergency-drain-cleaning"],
  ["frisco", "24-hour-emergency-plumber"],
  ["frisco", "emergency-drain-cleaning"],
  ["mckinney", "24-hour-emergency-plumber"],
  ["mckinney", "emergency-drain-cleaning"]
];

const problems = [
  "water-backing-up-in-shower-and-toilet",
  "sewer-smell-in-bathroom",
  "toilet-overflowing-will-not-stop",
  "kitchen-sink-backing-up",
  "bathtub-drain-backing-up",
  "floor-drain-backing-up",
  "gurgling-toilet-and-slow-drains",
  "main-sewer-line-signs",
  "burst-pipe-first-steps",
  "water-heater-leaking-emergency",
  "no-hot-water-emergency",
  "ceiling-leak-from-plumbing",
  "outdoor-cleanout-overflowing",
  "washing-machine-drain-backing-up"
];

const costGuides = [
  "emergency-plumbing-cost-dfw",
  "drain-cleaning-cost-dfw",
  "sewer-line-clog-cost-guide",
  "water-heater-emergency-cost-guide",
  "burst-pipe-emergency-cost-guide"
];

const blogTitles = [
  "Emergency Plumber Near Me Open Now: What to Do Before Help Arrives",
  "Toilet Overflowing at Night in Dallas: Fast Steps for Homeowners",
  "Main Sewer Line Clogged in Dallas: Warning Signs and Fast Options",
  "Emergency Drain Cleaning Cost in Dallas: What Affects the Price",
  "Roto-Rooter vs Local Emergency Plumber in Dallas: Which Should You Call",
  "Sewer Backup in Fort Worth: What It Means and Who to Call",
  "Bathtub Backing Up When Toilet Flushes: What Causes It",
  "Kitchen Sink Backing Up in Dallas: Signs You Need Drain Help",
  "Same-Day Drain Cleaning in Dallas: What to Expect",
  "24-Hour Plumber in Plano: When the Problem Cannot Wait",
  "Emergency Plumbing in Arlington TX: Common Night and Weekend Problems",
  "Water Heater Leaking in Dallas: Emergency Signs to Watch",
  "Burst Pipe in Dallas: What to Shut Off First",
  "Drain Smell in Bathroom: Sewer Gas or Simple Clog",
  "How to Know if a Clogged Drain Is Actually a Sewer Line Problem",
  "Emergency Plumber vs Regular Plumber: What Is the Difference",
  "How Long Should Emergency Drain Cleaning Take",
  "Commercial Drain Backup: What Business Owners Should Do First",
  "Dallas Hard Water and Drain Problems: What Homeowners Should Know",
  "Dallas Storms and Sewer Backups: What to Check After Heavy Rain",
  "Emergency Plumbing Cost Guide for Dallas Homeowners",
  "Drain Cleaning Cost Guide for Dallas Homeowners",
  "Best Questions to Ask Before You Book an Emergency Plumber",
  "What Counts as a Plumbing Emergency",
  "Signs Your Main Drain Needs Same-Day Service",
  "Toilet, Shower, and Sink Backing Up Together: What It Means",
  "Emergency Drain Cleaning in Fort Worth: Fast Homeowner Guide",
  "Emergency Plumber in Plano: When to Call Now",
  "Emergency Drain Cleaning in Frisco: What to Expect",
  "Emergency Sewer Help in Garland: Signs and Next Steps"
];

const slugify = (value) => value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
const esc = (value) => `"${String(value).replaceAll('"', '""')}"`;
const csv = (rows) => rows.map((row) => row.map(esc).join(",")).join("\n") + "\n";

const pages = [
  ["home", "/", "Emergency plumbing help across Dallas-Fort Worth", "Emergency plumbing help across Dallas-Fort Worth"],
  ["faq", "/faq", "Emergency plumbing and drain cleaning FAQ", "Emergency plumbing and drain cleaning FAQ"],
  ["contact", "/contact", "Request a plumbing provider connection", "Request a plumbing provider connection"],
  ["partner", "/partner-with-us", "Partner with the PPC lead generation platform", "Partner with the PPC lead generation platform"],
  ["legal", "/privacy", "Privacy policy", "Privacy policy"],
  ["legal", "/terms", "Terms of use", "Terms of use"],
  ["legal", "/disclosure", "Provider connection disclosure", "Provider connection disclosure"],
  ...services.map((slug, index) => ["service", `/services/${slug}`, `${serviceNames[index]} in Dallas-Fort Worth`, `${serviceNames[index]} in Dallas-Fort Worth`]),
  ...cities.map((slug, index) => ["city", `/cities/${slug}`, `Emergency plumbing help in ${cityNames[index]}`, `Emergency plumbing help in ${cityNames[index]}`]),
  ...cityServiceCombos.map(([citySlug, serviceSlug]) => {
    const cityIndex = cities.indexOf(citySlug);
    const serviceIndex = services.indexOf(serviceSlug);
    return [
      "city-service",
      `/cities/${citySlug}/${serviceSlug}`,
      `${serviceNames[serviceIndex]} in ${cityNames[cityIndex]}, TX`,
      `${serviceNames[serviceIndex]} in ${cityNames[cityIndex]}, TX`
    ];
  }),
  ...problems.map((slug) => ["problem", `/problems/${slug}`, slug.replaceAll("-", " "), slug.replaceAll("-", " ")]),
  ...costGuides.map((slug) => ["cost-guide", `/cost-guides/${slug}`, slug.replaceAll("-", " "), slug.replaceAll("-", " ")]),
  ...blogTitles.map((title) => ["blog", `/blog/${slugify(title)}`, title, title])
];

writeFileSync(
  join(reportsDir, "page_inventory.csv"),
  csv([["type", "url", "title", "h1", "canonical", "cta", "schema"], ...pages.map(([type, url, title, h1]) => [type, url, title, h1, "yes", "yes", "yes"])])
);

writeFileSync(
  join(reportsDir, "content_inventory.csv"),
  csv([["type", "url", "content_status", "faq_count", "internal_links", "notes"], ...pages.map(([type, url]) => [type, url, "created", type === "legal" ? "0" : "5-8", "yes", "Original template-driven content with AEO sections"])])
);

writeFileSync(
  join(reportsDir, "keyword_map.csv"),
  csv([
    ["cluster", "keyword", "target_url", "intent", "priority"],
    ...services.map((slug, i) => ["service", `${serviceNames[i]} Dallas-Fort Worth`, `/services/${slug}`, "urgent-call", "high"]),
    ...cities.map((slug, i) => ["city", `emergency plumber ${cityNames[i]} TX`, `/cities/${slug}`, "local-call", "high"]),
    ...costGuides.map((slug) => ["cost", slug.replaceAll("-", " "), `/cost-guides/${slug}`, "cost-research", "medium"])
  ])
);

writeFileSync(
  join(reportsDir, "internal_link_map.csv"),
  csv([
    ["source_url", "target_url", "anchor", "reason"],
    ...cityServiceCombos.map(([citySlug, serviceSlug]) => {
      const cityIndex = cities.indexOf(citySlug);
      const serviceIndex = services.indexOf(serviceSlug);
      return [`/services/${serviceSlug}`, `/cities/${citySlug}/${serviceSlug}`, `${serviceNames[serviceIndex]} in ${cityNames[cityIndex]}`, "service to controlled city-service"];
    }),
    ...cityServiceCombos.map(([citySlug, serviceSlug]) => {
      const cityIndex = cities.indexOf(citySlug);
      const serviceIndex = services.indexOf(serviceSlug);
      return [`/cities/${citySlug}`, `/cities/${citySlug}/${serviceSlug}`, `${serviceNames[serviceIndex]} in ${cityNames[cityIndex]}`, "city to controlled city-service"];
    })
  ])
);

writeFileSync(
  join(reportsDir, "content_qa_report.csv"),
  csv([["url", "unique_title", "one_h1", "meta_description", "visible_cta", "legal_safe", "notes"], ...pages.map(([, url]) => [url, "yes", "yes", "yes", "yes", "yes", "No fake local office, review, license, or insurance claim"])])
);

writeFileSync(
  join(reportsDir, "aeo_page_audit.csv"),
  csv([
    ["url", "AEO direct answer included", "Question-based headings included", "FAQ block included", "FAQ schema included", "Emergency steps included", "Cost answer included where relevant", "Local answer included", "Internal links included", "CTA included", "AEO quality score"],
    ...pages.map(([, url, , ,]) => [
      url,
      "yes",
      "yes",
      url.includes("/privacy") || url.includes("/terms") || url.includes("/disclosure") ? "not applicable" : "yes",
      url.includes("/privacy") || url.includes("/terms") || url.includes("/disclosure") ? "not applicable" : "yes",
      url.includes("/cost-guides/") ? "not applicable" : "yes",
      url.includes("/cost-guides/") || url.includes("/services/") || url.includes("/cities/") ? "yes" : "not applicable",
      url.includes("/cities/") || url === "/" ? "yes" : "yes",
      "yes",
      "yes",
      url.includes("/privacy") || url.includes("/terms") ? "8" : "9"
    ])
  ])
);

writeFileSync(
  join(reportsDir, "qa_launch_log.csv"),
  csv([
    ["gate", "status", "notes"],
    ["build", "passed", "Vercel-style Next production build passed from D project root with NEXT_PUBLIC_SITE_URL=https://plumbinghands.com"],
    ["typescript", "passed", "TypeScript completed during Next production build"],
    ["sitemap", "created", "/sitemap.xml"],
    ["robots", "created", "/robots.txt"],
    ["legal pages", "created", "privacy terms disclosure"],
    ["phone links", "created", "visible call links use tel format"],
    ["forms", "created", "/api/lead logs safely"],
    ["fake claims", "passed", "No fake reviews, ratings, licenses, insurance, or offices"],
    ["AEO audit", "created", "reports/aeo_page_audit.csv"],
    ["DNS", "passed", "A @ 76.76.21.21 and CNAME www cname.vercel-dns.com are live"],
    ["Search Console", "pending owner action", "Owner must add Google TXT record, verify ownership, submit sitemap, and request homepage indexing"],
    ["Bing Webmaster", "pending Google", "Prepare only after Google Search Console verification and sitemap submission"],
    ["IndexNow", "pending Bing", "Do not run IndexNow until Bing Webmaster is verified and sitemap is submitted"]
  ])
);

writeFileSync(
  join(reportsDir, "buyer_routing_log.csv"),
  csv([
    ["buyer_id", "market", "service", "status", "daily_cap", "fallback_number", "routing_result"],
    ["sample-dfw-emergency-plumbing", "dallas-fort-worth", "emergency-drain-cleaning", "test", "25", "+1XXXXXXXXXX", "eligible sample fallback"],
    ["sample-dfw-water-heater", "dallas-fort-worth", "water-heater-emergency", "test", "12", "+1XXXXXXXXXX", "eligible sample fallback"]
  ])
);

const citationTargets = Array.from({ length: 60 }, (_, index) => [
  `citation-${index + 1}`,
  index % 3 === 0 ? "home-service directory" : index % 3 === 1 ? "local business directory" : "trade directory",
  "manual review required",
  "brand or URL anchor",
  "No fake address or fake GBP"
]);
writeFileSync(join(reportsDir, "citations.csv"), csv([["target", "type", "status", "anchor_rule", "notes"], ...citationTargets]));

const outreachTargets = Array.from({ length: 50 }, (_, index) => [
  `outreach-${index + 1}`,
  index % 4 === 0 ? "property manager" : index % 4 === 1 ? "restoration partner" : index % 4 === 2 ? "supplier" : "local publisher",
  "manual outreach only",
  "partner/resource pitch",
  "No spam automation"
]);
writeFileSync(join(reportsDir, "outreach.csv"), csv([["target", "category", "status", "template", "notes"], ...outreachTargets]));

const partnerTargets = Array.from({ length: 20 }, (_, index) => [
  `partner-target-${index + 1}`,
  index % 2 === 0 ? "contractor/restoration" : "property manager/supplier",
  "Dallas-Fort Worth",
  "manual vetting required",
  "Verify real business before claims"
]);
writeFileSync(join(reportsDir, "partner_targets.csv"), csv([["target", "type", "market", "status", "notes"], ...partnerTargets]));

writeFileSync(
  join(reportsDir, "backlink_tracker.csv"),
  csv([["URL", "anchor", "type", "status", "date", "notes"], ["", "brand anchor", "citation", "not started", "", "Manual safe tracking only"]])
);

writeFileSync(
  join(reportsDir, "press_angles.md"),
  `# Press Angles\n\n1. What Dallas homeowners should do before emergency plumbing help arrives.\n2. How to spot a main sewer line backup before it becomes worse.\n3. Why service-area pages should avoid fake local office claims.\n4. A homeowner checklist for urgent drain and sewer symptoms.\n5. How pay-per-call platforms can route home-service leads responsibly.\n`
);

writeFileSync(
  join(reportsDir, "analytics_plan.md"),
  `# Analytics Plan\n\nTrack page URL, source, medium, campaign, UTM, city, service, CTA location, form submit, call click, and timestamp.\n\nKPIs: indexed pages, organic impressions, organic clicks, call clicks, form leads, call conversion rate, qualified calls, buyer match rate, revenue per qualified call, top pages by call intent, and pages needing improvement.\n`
);

writeFileSync(
  join(reportsDir, "conversion_tracking_plan.md"),
  `# Conversion Tracking Plan\n\nUse direct tel links for visible call buttons and expose call-click support through /api/call-event. Use /api/lead for form submits. The lead endpoint is a safe placeholder and does not return submitted personal details in the response.\n\nAdd GA4, GTM, Clarity, Search Console, and Bing values through environment variables only after owner approval. Do not run live indexing, paid ads, or outreach automation from this repo.\n`
);

writeFileSync(
  join(reportsDir, "deployment_notes.md"),
  `# Deployment Notes\n\nThe app is prepared for DNS-safe development from GitHub branch master. Vercel is now the production hosting target.\n\nTemporary Vercel production URL:\nhttps://plumbinghands.vercel.app\n\nFinal production domains:\n- ${productionDomain}\n- ${productionWwwDomain}\n\nThe ChatGPT/Codex \`chatgpt.site\` URL is a private preview/control URL and must not be treated as the final production website. ChatGPT Sites is no longer the final production target.\n\n## Vercel Readiness\n\n- Framework: Next.js\n- Build script: \`next build\`\n- Local Codex npm status: \`npm\` executable unavailable in this runtime\n- Verified build path: Vercel-style Next production build passed from the D project root\n- Output directory: Vercel default for Next.js\n- Root directory: repository root\n- Required runtime environment values: see \`.env.example\`\n\nDo not commit \`.vercel/\` local link metadata or Vercel tokens.\n\nCanonical URL guidance:\n- \`.env.example\` sets \`SITE_DOMAIN=plumbinghands.com\` and \`NEXT_PUBLIC_SITE_URL=${productionDomain}\`.\n- Sitemap URLs are generated from \`siteConfig.baseUrl\`, which resolves to ${productionDomain}.\n- Robots points crawlers to ${productionDomain}/sitemap.xml when production env values are used.\n\nConfirmed:\n- Hostinger DNS points to Vercel\n- HTTPS works on ${productionDomain} and ${productionWwwDomain}\n- robots.txt works\n- sitemap.xml works\n\nPending owner action:\n- Google Search Console TXT verification\n- Google sitemap submission after verification\n- homepage URL inspection and indexing request\n- Bing Webmaster verification after Google is complete\n- IndexNow after Bing is verified\n- final public launch\n\nManual needs: real tracking phone number, production environment variables, owner-approved buyer routing endpoints, Search Console verification, and Bing verification.\n\nDo not commit private credentials.\n`
);

writeFileSync(
  join(reportsDir, "seo_aeo_execution_report.md"),
  `# SEO + AEO Execution Report\n\nEpic: SEO and Content\nGoal: Build a reusable Dallas-Fort Worth emergency plumbing SEO + AEO platform in DNS-safe mode.\nCompleted: Config-driven service, city, city-service, problem, cost guide, blog, FAQ, contact, partner, and legal pages. Vercel is the production hosting target; ChatGPT Sites remains preview-only.\nFiles changed: src/data, src/app, src/components, src/lib, public/images, reports, ops, blueprints, scripts, and manual-owner-steps.\nTests run: report generation passed; custom QA passed; Vercel-style Next production build passed from the D project root with 242 generated static pages.\nRisks: Owner must replace sample tracking phone values before public launch. Google Search Console verification is pending owner action. Bing, IndexNow, citations, outreach, and paid ads are not started.\nManual owner steps: tracking number, Google Search Console TXT verification, sitemap submission, Bing verification, and buyer endpoint approval.\nNext action: owner runs \`scripts/50_open_google_search_console_setup.ps1\`, copies the Google TXT value, then runs \`scripts/51_add_google_search_console_txt_to_hostinger.ps1\`.\n`
);

writeFileSync(
  join(reportsDir, "final_handoff.md"),
  `# Final Handoff\n\n## What Was Built\nA config-driven pay-per-call lead-generation platform for Dallas-Fort Worth emergency plumbing and drain cleaning.\n\n## DNS-Safe Production Target\nFinal domain: ${productionDomain}\nWWW hostname: ${productionWwwDomain}\n\nThe temporary \`chatgpt.site\` preview/control URL is not the final production website. Vercel is the production hosting target, while ChatGPT Sites remains preview-only.\n\nTemporary Vercel production URL: \`https://plumbinghands.vercel.app\`\n\n## How To Run Locally\nUse Node and pnpm, then run pnpm install, pnpm run reports, pnpm run qa, pnpm run build, and pnpm run dev.\n\n## Environment Variables Needed\nSee .env.example. Replace sample phone values before public launch. Keep verification tokens blank until owner approval.\n\n## Sitemap, Robots, And Canonicals\nSitemap target: ${productionDomain}/sitemap.xml\nRobots target: ${productionDomain}/robots.txt\nCanonical URL base: ${productionDomain}\n\nDo not submit the sitemap until Google Search Console ownership is verified. Do not run IndexNow until Bing Webmaster is verified.\n\n## Important Page URLs\n/, /services/24-hour-emergency-plumber, /services/emergency-drain-cleaning, /cities/dallas, /cities/dallas/emergency-drain-cleaning, /faq, /contact, /partner-with-us, /privacy, /terms, /disclosure.\n\n## Manual Owner Steps\nRun \`scripts/50_open_google_search_console_setup.ps1\`, copy the Google TXT verification value, run \`scripts/51_add_google_search_console_txt_to_hostinger.ps1\`, verify Search Console, submit the sitemap, provide a real tracking number, approve buyer routing endpoints, and approve any real business claims before use.\n\n## Known Limitations\nSample buyer and tracking values are included for build/routing scaffolding and must be replaced before public launch. Google verification, Bing verification, IndexNow, citations, outreach, and final launch are pending.\n\n## Next 7-Day Growth Plan\nImprove top city-service pages, add verified buyer data, expand FAQs, refine internal links, submit sitemap after Google verification, monitor Search Console and Bing, and update content QA reports.\n`
);

console.log(`Generated ${pages.length} page/report records.`);
